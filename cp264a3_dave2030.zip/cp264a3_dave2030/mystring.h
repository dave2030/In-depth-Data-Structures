#include <stdio.h>

int letter_count(char *);
void lower_case(char *);
int word_count(char *);
void trim(char *);