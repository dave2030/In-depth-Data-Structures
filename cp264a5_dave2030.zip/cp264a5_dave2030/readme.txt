Name:Shyam Dave
ID:180332030
Email:dave2030@mylaurier.ca
WorkID: cp264a5
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]
Q1
1. display records in linked list               [2/2/]
2. search function                              [2/2/] 
3. insert function                              [2/2/]
4. delete function                              [2/2/]  
5. clean function                               [2/2/]

Q2 
1. new node,display forward/backward functions  [4/4/]
2. insert start/end functions                   [3/3/]
3. delete start/end functions                   [3/3/]
4. clean function                               [2/2/]

Q3 
1. add function                                 [4/4/]
2. Fibonacci function                           [4/4/]
		
Total:                                         [30/30/]


Test result:
Q1 output: (copy the screen output of your test run) 
Ali       88.0
Allison   67.7
Bodnar    93.6
Chabot    80.4
Costa     45.1
Dabu      74.4
Eccles    77.8
Giblett   59.1
Hatch     66.5
He        85.7
Koreck    77.4
Lamont    98.1
Myrie     76.7
Parr      92.5
Pereira   80.3
Peters    82.3
Smith     60.1
Suglio    85.7
Sun       67.7
Wang      98.1
Found:Moore, 92.00 

Q2 output: (copy the screen output of your test run) 
9 8 7 6 5 4 3 2 1 0
0 1 2 3 4 5 6 7 8 9
8 7 6 5 4 3 2 1
a b c d e f g h i j

Q3 output: (copy the screen output of your test run)
 
1111111111111111111+8888888888888888889=10000000000000000000
Fibonacci(100)=354224848179261915075


Comments (if any): 