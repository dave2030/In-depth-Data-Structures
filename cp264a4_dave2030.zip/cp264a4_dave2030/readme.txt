Name:Shyam Dave
ID:180332030
Email:dave2030@mylaurier.ca
WorkID: cp264a4
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]

Q1
1. set_stopword function                        [4/4/]
2. functions of containing word in dictionary   [4/4/]
3. process_word function                        [4/4/]
4. save_to_file function                        [4/4/]

Q2
1. structure                                    [2/2/]
2. import data: load data to data structure     [4/4/]
3. report data: stats computing                 [4/4/]
4. report data: process data, output to file    [4/4/]

Total:                                         [30/30/]

Test result:
Q1 output: (copy the screen output of your test run) 
loading stop words done
word processing done
saving result to file done
Line count                   2
Word count                  10
Keyword count                3
Keyword              frequency
first                        1
test                         2
second                       1


Q2 output: (copy the screen output of your test run) 
Letter grade
Myrie          B
Hatch          C
Costa          F
Dabu           B
Sun            C
Chabot         B
Giblett        D
Suglio         A
Smith          C
Bodnar         A
Allison        C
Koreck         B
Parr           A
Lamont         A
Peters         B
Wang           A
Eccles         B
Pereira        B
He             A
Ali            A

Stats summary
count:              20
average:            77.9
standard deviation: 13.5
median:             79.1
