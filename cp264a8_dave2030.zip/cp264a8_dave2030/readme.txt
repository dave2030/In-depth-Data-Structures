Name:Shyam Dave
ID:180332030
Email:dave2030@mylaurier.ca
WorkID: cp264a8
Statement: I claim that the enclosed submission is my individual work 

Evaluation grid: [self-evaluation/total/marker-evaluation]

Q1 
1. height, balance_factor, is_avl functions     [5/5/] 
2. rotate_left, rotate_right functions          [5/5/] 
3. insert function                              [5/5/]
4. delete function                              [5/5/]

Q2
1. merge tree function                          [5/5/]
2. merge data function, stats aggregation       [5/5/] 


Test result:
Q1 output: (copy the screen output of your test run) 
Build AVL by inserting key-value (i, i) for if from 0 to 8
Display tree: name, socre, height
|___3 3.0 4
    |___5 5.0 3
        |___6 6.0 2
            |___7 7.0 1
        |___4 4.0 1
    |___1 1.0 2
        |___2 2.0 1
        |___0 0.0 1

is_val:1
Inorder traversal
0              0.0
1              1.0
2              2.0
3              3.0
4              4.0
5              5.0
6              6.0
7              7.0
Delete nodes of even number keys
|___5 5.0 3
    |___7 7.0 1
    |___3 3.0 2
        |___1 1.0 1

is_val:1
1              1.0
3              3.0
5              5.0
7              7.0

Q2 output: (copy the screen output of your test run) 

Load data from file marks.txt.1
grade report
Bodnar         93.6
Chabot         80.4
Costa          45.1
Dabu           74.4
Giblett        59.1
Hatch          66.5
Myrie          76.7
Smith          60.1
Suglio         85.7
Sun            67.7

statistics summary
count          10
mean           70.9
stddev         13.5

Load data from file marks.txt.2
grade report
Ali            88.0
Allison        67.7
Eccles         77.8
He             85.7
Koreck         77.4
Lamont         98.1
Parr           92.5
Pereira        80.3
Peters         82.3
Wang           98.1

statistics summary
count          10
mean           84.8
stddev         9.2

Merge
grade report
Ali            88.0
Allison        67.7
Bodnar         93.6
Chabot         80.4
Costa          45.1
Dabu           74.4
Eccles         77.8
Giblett        59.1
Hatch          66.5
He             85.7
Koreck         77.4
Lamont         98.1
Myrie          76.7
Parr           92.5
Pereira        80.3
Peters         82.3
Smith          60.1
Suglio         85.7
Sun            67.7
Wang           98.1

statistics summary
count          20
mean           77.9
stddev         13.5

Write report to file report.txt

Read file report.txt
grade report
Ali            88.0   A
Allison        67.7   C
Bodnar         93.6   A
Chabot         80.4   B
Costa          45.1   F
Dabu           74.4   B
Eccles         77.8   B
Giblett        59.1   D
Hatch          66.5   C
He             85.7   A
Koreck         77.4   B
Lamont         98.1   A
Myrie          76.7   B
Parr           92.5   A
Pereira        80.3   B
Peters         82.3   B
Smith          60.1   C
Suglio         85.7   A
Sun            67.7   C
Wang           98.1   A

simple statistics summary
count          20
mean           77.9
stddev         13.5


Comments (if any):
