 Name:shyam dave
ID:180332030
Email:dave2030@mylaurier.ca
WorkID: cp264a10
Statement: I claim that the enclosed submission is my individual work 

Evaluation grid: [self-evaluation/total/marker-evaluation]
Q1 
1. new_graph, clean_graph                         [3/3/] 
2. add_edge, get_weight                           [4/4/]  

Q2 
1. new_edgelist, clean_edglist                    [4/4/] 
2. add_edge_start, add_edge_end, weight_edgelist  [4/4/]

Q3  
1. prim algorithm for MST                         [5/5/]
2. shortest path tree by Dijsktra algorithm       [5/5/]
3. shortest path by Dijsktra algorithm            [5/5/]

Total:                                           [30/30/]

Test result:
Q1 output: (copy the screen output of your test run) 
weighted graph in adjacency list
order: 5
size: 12
node from: (to weight)
node 0: (1, 7) (2, 3)
node 1: (0, 7) (2, 4) (3, 9) (4, 11)
node 2: (0, 3) (1, 4) (3, 10)
node 3: (2, 10) (1, 9)
node 4: (1, 11)
graph is deleted

Q2 output: (copy the screen output of your test run)
weighted graph in edge list
size: 4
format: (from, to, weight)
(0, 2, 3)
(2, 1, 4)
(1, 3, 9)
(1, 4, 11)
weight: 27
graph is deleted

Q3 output: (copy the screen output of your test run)

weighted graph in adjacency list
order: 5
size: 12
node from: (to weight)
node 0: (1, 7) (2, 3)
node 1: (0, 7) (2, 4) (3, 9) (4, 11)
node 2: (0, 3) (1, 4) (3, 10)
node 3: (2, 10) (1, 9)
node 4: (1, 11)

MST by Prim's algorithm
weighted graph in edge list
size: 4
format: (from, to, weight)
(0, 2, 3)
(2, 1, 4)
(1, 3, 9)
(1, 4, 11)
weight: 27
MST is deleted

SPT by Dijsktra's algorithm
weighted graph in edge list
size: 4
format: (from, to, weight)
(0, 2, 3)
(0, 1, 7)
(2, 3, 10)
(1, 4, 11)
SPT is deleted

Shortest path from 0 to 4
weighted graph in edge list
size: 2
format: (from, to, weight)
(0, 1, 7)
(1, 4, 11)
The length of the shortest path: 18
SP is deleted

graph is deleted
Comments (if any):