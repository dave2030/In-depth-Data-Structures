Name:Shyam Dave	
ID:180332030
Email:dave2030@mylaurier.ca
WorkID: cp264a6
Statement: I claim that the enclosed submission is my individual work 

Evaluation grid: [self-evaluation/total/marker-evaluation]

Q1
1. new_node, clean in common                    [4/4/]
2. enqueue and dequeue functions                [4/4/]
4. clean_queue                                  [2/2/] 

Q2
1. push and pop functions                       [4/4/]
2. clean_stack                                  [2/2/] 

Q3
1. infix_to_postfix function                    [8/8/]
2. evaluate_postfix function                    [6/6/] 

Total:                                         [30/30/]

Test result:
Q1 output: (copy the screen output of your test run) 
enqueue: 9-((3*4)+8)/4
display queue: 9 - ( ( 3 * 4 ) + 8 ) / 4
dequeue: 9 - ( ( 3 * 4 ) + 8 ) / 4

Q2 output: (copy the screen output of your test run) 
push: 0123456789+-*/%()
display stack: ) ( % / * - + 9 8 7 6 5 4 3 2 1 0
pop: ) ( % / * - + 9 8 7 6 5 4 3 2 1 0

Q3 output: (copy the screen output of your test run) 
infix: 9-((3*4)+8)/4
postfix: 9 3 4 * 8 + 4 / -
evaluation: 4

Comments (if any):
